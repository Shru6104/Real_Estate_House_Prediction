package com.example.loanapp.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "loan_details")
public class LoanDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String loanType;
    private String requiredLoanAmount;
    private String loanDuration;
    private String hasExistingLoan;
    private String preferredEmiDate;

    private String saleAgreement;
    private String ec;
    private String dealerInvoice;
    private String quotation;
    private String admissionLetter;
    private String feeStructure;
}

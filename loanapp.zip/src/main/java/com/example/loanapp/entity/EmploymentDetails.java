package com.example.loanapp.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "employment_details")
public class EmploymentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String occupationType;
    private String employerName;
    private String designation;
    private String annualIncome;
    private String workExperience;
    private String location;
    private String officeAddress;

    private String salaryProof;
    private String employmentProof;
    private String businessProof;
    private String gstCertificate;
    private String itr;
    private String bankStatements;
}

package com.example.loanapp.service;

import com.example.loanapp.entity.EmploymentDetails;
import com.example.loanapp.repository.EmploymentDetailsRepository;
import org.springframework.stereotype.Service;

@Service
public class EmploymentDetailsService {
    private final EmploymentDetailsRepository repository;

    public EmploymentDetailsService(EmploymentDetailsRepository repository) {
        this.repository = repository;
    }

    public EmploymentDetails saveEmploymentDetails(EmploymentDetails details) {
        return repository.save(details);
    }
}

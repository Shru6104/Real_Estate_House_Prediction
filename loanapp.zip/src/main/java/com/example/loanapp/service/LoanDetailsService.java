package com.example.loanapp.service;

import com.example.loanapp.entity.LoanDetails;
import com.example.loanapp.repository.LoanDetailsRepository;
import org.springframework.stereotype.Service;

@Service
public class LoanDetailsService {
    private final LoanDetailsRepository repository;

    public LoanDetailsService(LoanDetailsRepository repository) {
        this.repository = repository;
    }

    public LoanDetails saveLoanDetails(LoanDetails details) {
        return repository.save(details);
    }
}

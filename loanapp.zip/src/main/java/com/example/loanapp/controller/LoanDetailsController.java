package com.example.loanapp.controller;

import com.example.loanapp.entity.LoanDetails;
import com.example.loanapp.service.LoanDetailsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/loan")
@CrossOrigin(origins = "http://localhost:3000")
public class LoanDetailsController {

    private final LoanDetailsService service;

    public LoanDetailsController(LoanDetailsService service) {
        this.service = service;
    }

    @PostMapping
    public LoanDetails saveLoanDetails(@RequestBody LoanDetails details) {
        return service.saveLoanDetails(details);
    }
}

package com.example.loanapp.controller;

import com.example.loanapp.entity.EmploymentDetails;
import com.example.loanapp.service.EmploymentDetailsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employment")
@CrossOrigin(origins = "http://localhost:3000")
public class EmploymentDetailsController {

    private final EmploymentDetailsService service;

    public EmploymentDetailsController(EmploymentDetailsService service) {
        this.service = service;
    }

    @PostMapping
    public EmploymentDetails saveEmploymentDetails(@RequestBody EmploymentDetails details) {
        return service.saveEmploymentDetails(details);
    }
}

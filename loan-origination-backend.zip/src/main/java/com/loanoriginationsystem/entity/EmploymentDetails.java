package com.loanoriginationsystem.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "employment_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmploymentDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String occupationType;
    private String employerName;
    private String designation;
    private Double annualIncome;
    private Integer workExperience;
    private String location;
    @Column(length = 500)
    private String officeAddress;
    private String salaryProofPath;
    private String employmentProofPath;
    private String businessProofPath;
    private String gstCertificatePath;
    private String itrPath;
    private String bankStatementsPath;
}

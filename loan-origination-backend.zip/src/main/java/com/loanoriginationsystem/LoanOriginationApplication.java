package com.loanoriginationsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanOriginationApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanOriginationApplication.class, args);
    }
}

package com.loanoriginationsystem.service.impl;

import com.loanoriginationsystem.entity.EmploymentDetails;
import com.loanoriginationsystem.repository.EmploymentDetailsRepository;
import com.loanoriginationsystem.service.EmploymentDetailsService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmploymentDetailsServiceImpl implements EmploymentDetailsService {
    private final EmploymentDetailsRepository repository;
    public EmploymentDetailsServiceImpl(EmploymentDetailsRepository repository) {
        this.repository = repository;
    }
    @Override
    public EmploymentDetails saveEmploymentDetails(EmploymentDetails details) {
        return repository.save(details);
    }
    @Override
    public List<EmploymentDetails> getAllEmploymentDetails() {
        return repository.findAll();
    }
    @Override
    public EmploymentDetails getEmploymentDetailsById(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Employment details not found"));
    }
}

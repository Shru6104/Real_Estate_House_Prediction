package com.loanoriginationsystem.service;

import com.loanoriginationsystem.entity.EmploymentDetails;
import java.util.List;

public interface EmploymentDetailsService {
    EmploymentDetails saveEmploymentDetails(EmploymentDetails details);
    List<EmploymentDetails> getAllEmploymentDetails();
    EmploymentDetails getEmploymentDetailsById(Long id);
}

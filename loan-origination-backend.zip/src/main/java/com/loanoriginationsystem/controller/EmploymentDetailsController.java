package com.loanoriginationsystem.controller;

import com.loanoriginationsystem.entity.EmploymentDetails;
import com.loanoriginationsystem.service.EmploymentDetailsService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.*;

@RestController
@RequestMapping("/api/employment")
@CrossOrigin(origins = "http://localhost:3000")
public class EmploymentDetailsController {
    private final EmploymentDetailsService service;
    public EmploymentDetailsController(EmploymentDetailsService service) {
        this.service = service;
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public EmploymentDetails createEmploymentDetails(
            @RequestPart("data") EmploymentDetails details,
            @RequestPart(value = "salaryProof", required = false) MultipartFile salaryProof
    ) throws IOException {
        Path uploadPath = Paths.get("uploads/employment");
        if (!Files.exists(uploadPath)) Files.createDirectories(uploadPath);
        if (salaryProof != null && !salaryProof.isEmpty()) {
            String fileName = "salary_" + System.currentTimeMillis() + "_" + salaryProof.getOriginalFilename();
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(salaryProof.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            details.setSalaryProofPath(filePath.toString());
        }
        return service.saveEmploymentDetails(details);
    }

    @GetMapping
    public java.util.List<EmploymentDetails> getAllEmploymentDetails() {
        return service.getAllEmploymentDetails();
    }

    @GetMapping("/{id}")
    public EmploymentDetails getEmploymentDetails(@PathVariable Long id) {
        return service.getEmploymentDetailsById(id);
    }
}
